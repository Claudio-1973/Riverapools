import { useEffect, useMemo, useState } from "react";
import { ArrowRight, Check, ChevronDown, CircleAlert, Clock3, Droplets, Filter, Menu, Phone, Search, ShieldCheck, Waves, X, Mail, MapPin } from "lucide-react";
import { Button } from "@/components/ui/button";
import { ChatWidget } from "@/components/ChatWidget";

type Topic = {
  id: string;
  number: string;
  kicker: string;
  title: string;
  intro: string;
  facts: string[];
  takeaway: string;
  tags: string[];
};

const topics: Topic[] = [
  {
    id: "hard-water",
    number: "01",
    kicker: "Water chemistry",
    title: "High calcium hardness: why local tile scales",
    intro: "Riverside County heat turns hard fill water into a mineral trap. As water evaporates in Murrieta and Temecula, calcium stays behind and concentrates on tile, spillways, and equipment.",
    tags: ["calcium", "scale", "LSI"],
    facts: [
      "Local hose bibs often test at 250–450+ ppm calcium before the water even enters the pool.",
      "When pH rises above 7.6 and water heats up, a positive LSI lets calcium carbonate precipitate onto the easiest surfaces.",
      "Keeping pH around 7.3–7.5 and total alkalinity balanced helps manage scaling tendencies.",
      "Scale management is an ongoing chemistry task, not a one-time scrub. Routine balancing prevents buildup."
    ],
    takeaway: "Scale is a water-profile problem, not just a dirty tile problem. We balance the water to protect your finish and equipment."
  },
  {
    id: "salt-cell",
    number: "02",
    kicker: "Equipment care",
    title: "Salt cell maintenance: the real cost of neglect",
    intro: "A salt pool still needs inspection. In hard water, heat and high pH inside the electrolytic cell can plate calcium directly onto the plates and ruin a reliable chlorinator.",
    tags: ["salt systems", "chlorinator", "maintenance"],
    facts: [
      "Salt cells operate at a high local pH internally, accelerating scale bridges during peak summer use.",
      "Scale restricts flow, creates false low-salt readings, and makes the control board work harder while chlorine production falls.",
      "Gentle flushing and targeted acid baths (only when necessary) remove scale without damaging the delicate plate coating.",
      "Never scrape between plates with metal tools; damage to the ruthenium coating is permanent and ruins the cell."
    ],
    takeaway: "Quarterly cell inspection preserves a five-to-seven-year operating life. A blinking inspect-cell warning is a call to action, not a light to ignore."
  },
  {
    id: "storm",
    number: "03",
    kicker: "Weather response",
    title: "Santa Ana winds: the 48-hour recovery plan",
    intro: "A wind event in Southwest Riverside County brings more than leaves. Silt carries phosphates, pollen, and organic load that can consume a pool's free chlorine within hours.",
    tags: ["Santa Ana", "silt", "storm recovery"],
    facts: [
      "Hours 1–6: Clear skimmer and pump baskets, ensure water levels are safe, and check the baseline filter pressure.",
      "Hours 6–24: Shock to restore chlorine levels, brush walls and floor, and let the filter run continuously.",
      "Hours 24–48: Wash cartridges or backwash to remove the fine silt that ordinary running will not clear.",
      "Do not let a pump run dry on clogged baskets, or stack acidic tablets to solve a massive organic storm load."
    ],
    takeaway: "The first few hours protect the equipment pad. Debris removal, chemical reset, and filter cleaning must work together."
  },
  {
    id: "phosphates",
    number: "04",
    kicker: "Sanitizer demand",
    title: "Why chlorine disappears overnight: the phosphate factor",
    intro: "When chlorine drops to zero even though the pool looks clear, invisible phosphate load may be feeding microscopic algae faster than your sanitizer can keep up.",
    tags: ["phosphates", "chlorine demand", "algae prevention"],
    facts: [
      "Fertilizer drift, windblown soil, and landscape runoff introduce phosphate nutrients into the pool water.",
      "At high levels, algae reproduce continuously. Basic test strips do not measure phosphate; a specialized test is required.",
      "Professional phosphate removers bind the nutrient into a precipitate that the filter captures (causing temporary cloudiness).",
      "A complete filter cleaning is needed a few days after treatment to clear the heavily loaded filter media."
    ],
    takeaway: "Repeatedly adding chlorine treats the symptom. We test phosphate when the water repeatedly loses sanitizer to address the root cause."
  },
  {
    id: "filters",
    number: "05",
    kicker: "Filtration",
    title: "Cartridge, D.E., or sand: what a clean filter protects",
    intro: "The filter catches what chemistry cannot: dust, dead algae, body oils, and silt. A neglected filter raises backpressure, overheats pumps, and sends debris back into the pool.",
    tags: ["cartridge", "D.E.", "sand filters"],
    facts: [
      "Cartridge systems filter roughly 10–15 microns and need full disassembly, degreasing, and pleat-by-pleat washing several times a year.",
      "D.E. systems require regular backwashing, fresh D.E. powder, and an annual grid inspection for tears.",
      "Sand filters need routine backwashing and media replacement every few years to prevent channeling.",
      "The pressure gauge is the trigger: 8–10 PSI above the clean baseline means flow is restricted and a teardown is due."
    ],
    takeaway: "The pressure gauge is an early warning system. Objective monitoring prevents pump motor burnout and crushed internal manifolds."
  },
  {
    id: "service",
    number: "06",
    kicker: "Service standards",
    title: "The true cost of splash-and-dash pool service",
    intro: "A four-minute basket empty and a few tabs is not a maintenance program. Water chemistry and the equipment pad need a qualified eye every single week.",
    tags: ["routine care", "water testing", "reliability"],
    facts: [
      "Dropping acidic trichlor tablets directly into a skimmer can send a concentrated acid slug through seals and heater components when the pump restarts.",
      "Overusing tablets continuously adds cyanuric acid, which eventually makes chlorine far less active.",
      "A complete visit tests pH, total alkalinity, calcium, CYA, and inspects the salt cell, filter pressure, and pump operation.",
      "Dependable care means catching small leaks or circulation issues before they become expensive breakdowns."
    ],
    takeaway: "Ask what gets tested, what gets recorded, and how equipment is inspected. The cheapest visit can quickly become the most expensive repair."
  },
  {
    id: "black-algae",
    number: "07",
    kicker: "Algae remediation",
    title: "Black algae: why normal shock does not kill it",
    intro: "Black or dark-teal spots that resist brushing are often cyanobacteria rooted into the pool surface. Its protective waxy layer blocks ordinary chlorine.",
    tags: ["black algae", "remediation", "brushing"],
    facts: [
      "Physical disruption with a sturdy stainless-steel or hybrid brush is the crucial first step to break the organism's shield.",
      "After opening the protective sheath, targeted high-chlorine treatments and localized brushing must follow.",
      "Brushing twice daily for a week, along with elevated free chlorine and compatible algaecides, is often required.",
      "Skipping days allows the algae to rebuild its protective coating and resist the chemicals all over again."
    ],
    takeaway: "A clear pool is not proof the organism is gone. We treat the root system aggressively and consistently to prevent seasonal returns."
  },
  {
    id: "pump",
    number: "08",
    kicker: "Energy & circulation",
    title: "Variable-speed pump schedules for triple-digit summers",
    intro: "Local pools need circulation through 90-degree water, but peak utility hours are expensive. A variable-speed schedule keeps turnover moving while avoiding full-speed operation all day.",
    tags: ["variable speed", "RPM", "energy efficiency"],
    facts: [
      "The pump affinity law means cutting speed in half drops power consumption drastically, while still moving significant water.",
      "A practical schedule runs at moderate speeds during peak skimming hours, and lower speeds overnight for constant filtration.",
      "Confirm minimum flow for all components: salt cells, heaters, and water features each have specific GPM requirements.",
      "The correct RPM depends on pipe diameter, filter pressure, and plumbing friction, not just guessing a speed."
    ],
    takeaway: "Efficiency is a system result. We coordinate your pump schedule with the filter, heater, salt cell, and automation."
  },
  {
    id: "green-pool",
    number: "09",
    kicker: "Restorative cleaning",
    title: "Green-pool recovery: clearing a neglected pool safely",
    intro: "When a pool turns green, dumping gallons of chlorine into the water isn't enough. A structured recovery plan clears the water without damaging the equipment.",
    tags: ["green pool", "shock", "recovery"],
    facts: [
      "Removing organic debris like leaves and branches first is critical; chlorine cannot overcome a pile of decomposing leaves on the floor.",
      "Heavy brushing breaks up algae colonies on walls and steps, exposing them to the shock treatment.",
      "The filter will load quickly and require frequent cleaning or backwashing during the first few days of recovery.",
      "Re-balancing pH and alkalinity ensures the high levels of chlorine remain effective against the aggressive algae bloom."
    ],
    takeaway: "Green pool recovery is an intensive process of filtration, chemistry, and labor. We use a systematic approach to bring clarity back safely."
  },
  {
    id: "cya",
    number: "10",
    kicker: "Water reset",
    title: "Cyanuric acid lock: the silent cause of cloudy water",
    intro: "Stabilizer (CYA) protects chlorine from UV rays, but it does not evaporate. Repeated tablet use can push CYA so high that chlorine stops working effectively.",
    tags: ["CYA", "cloudy water", "stabilizer"],
    facts: [
      "A useful operating window is 30–50 ppm CYA for traditional pools and 60–80 ppm for many saltwater pools.",
      "At 100+ ppm, the required free chlorine rises sharply. High CYA makes it nearly impossible to maintain a sanitary pool without massive chlorine additions.",
      "There is no dependable chemical additive that removes high CYA; safe, partial dilution with fresh water is the standard solution.",
      "Consistent monitoring of CYA levels dictates when to switch from stabilized tablets to liquid chlorine."
    ],
    takeaway: "If high chlorine still leaves the water cloudy, stop adding shock blindly. We test CYA accurately and choose a safe strategy."
  }
];

export default function Blog() {
  const [menu, setMenu] = useState(false);
  const [query, setQuery] = useState("");
  const [active, setActive] = useState<string | null>("hard-water");

  useEffect(() => {
    document.title = "Pool Cleaning & Maintenance Knowledge Center | Rivera Pool Care";
    
    const setMeta = (selector: string, attribute: string, value: string) => {
      const element = document.head.querySelector<HTMLMetaElement>(selector);
      if (element) element.setAttribute(attribute, value);
    };

    setMeta('meta[name="description"]', "content", "Ten practical pool cleaning and maintenance guides for Riverside County homeowners, covering chemistry, filtration, equipment, algae, weather, and restorative cleaning.");
    setMeta('link[rel="canonical"]', "href", "https://prospoolcare.com/blog");
    setMeta('meta[property="og:title"]', "content", "Pool Cleaning & Maintenance Knowledge Center | Rivera Pool Care");
    setMeta('meta[property="og:description"]', "content", "Ten practical pool cleaning and maintenance guides for Riverside County homeowners.");
    setMeta('meta[property="og:url"]', "content", "https://prospoolcare.com/blog");
    setMeta('meta[name="twitter:title"]', "content", "Pool Cleaning & Maintenance Knowledge Center | Rivera Pool Care");
    setMeta('meta[name="twitter:description"]', "content", "Ten practical pool cleaning and maintenance guides for Riverside County homeowners.");
  }, []);

  const filtered = useMemo(() => {
    const needle = query.trim().toLowerCase();
    return topics.filter((topic) => !needle || `${topic.title} ${topic.kicker} ${topic.intro} ${topic.tags.join(" ")} ${topic.facts.join(" ")}`.toLowerCase().includes(needle));
  }, [query]);

  return (
    <div className="min-h-[100dvh] bg-slate-50 text-foreground selection:bg-secondary selection:text-white">
      {/* HEADER */}
      <header className="bg-primary border-b border-white/10 sticky top-0 z-50">
        <nav className="container mx-auto max-w-7xl px-6 py-4 flex items-center justify-between gap-4" aria-label="Main navigation">
          <a href="/" className="flex items-center gap-2 text-white group">
            <span className="bg-white/10 p-2 rounded-xl text-secondary transition-colors group-hover:bg-white/20">
              <Droplets className="w-6 h-6" />
            </span>
            <span className="font-display font-extrabold text-xl leading-none tracking-tight">
              RIVERA<span className="font-medium text-sm block tracking-widest opacity-80">POOL CARE</span>
            </span>
          </a>
          
          <div className="hidden md:flex items-center gap-8">
            <a href="/#services" className="text-sm font-semibold text-white/90 hover:text-white transition-colors">Services</a>
            <a href="/#service-area" className="text-sm font-semibold text-white/90 hover:text-white transition-colors">Service Area</a>
            <a href="/blog" className="text-sm font-semibold text-secondary transition-colors">Knowledge Center</a>
            
            <div className="flex items-center gap-4 ml-2">
              <a href="tel:+19513839753" className="text-white font-bold flex items-center gap-2 hover:text-white/80 transition-colors">
                <Phone className="w-4 h-4 text-secondary" />
                (951) 383-9753
              </a>
              <Button asChild className="bg-secondary hover:bg-secondary/90 text-white rounded-full font-bold shadow-lg shadow-secondary/20">
                <a href="/#contact">Free Estimate</a>
              </Button>
            </div>
          </div>
          
          <button className="md:hidden p-2 text-white bg-white/10 rounded-lg" onClick={() => setMenu(!menu)} aria-label="Toggle menu">
            {menu ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </nav>
        
        {menu && (
          <div className="md:hidden absolute top-full left-0 right-0 bg-white border-b border-border shadow-xl p-4 flex flex-col gap-2 animate-in slide-in-from-top-2">
            <a href="/#services" className="px-4 py-3 text-left hover:bg-slate-50 rounded-lg font-semibold text-primary">Services</a>
            <a href="/#service-area" className="px-4 py-3 text-left hover:bg-slate-50 rounded-lg font-semibold text-primary">Service Area</a>
            <a href="/blog" className="px-4 py-3 text-left bg-slate-50 rounded-lg font-semibold text-primary">Knowledge Center</a>
            <div className="h-px bg-border my-2"></div>
            <a href="tel:+19513839753" className="px-4 py-3 text-left hover:bg-slate-50 rounded-lg font-bold text-primary flex items-center gap-2">
              <Phone className="w-5 h-5 text-secondary" /> (951) 383-9753
            </a>
            <Button asChild className="bg-secondary hover:bg-secondary/90 text-white w-full rounded-lg mt-2 py-6 text-lg font-bold">
              <a href="/#contact">Get an Estimate</a>
            </Button>
          </div>
        )}
      </header>

      <main>
        {/* HERO SECTION */}
        <section className="relative overflow-hidden bg-primary px-6 py-16 lg:py-24">
          <div className="absolute -right-24 -top-28 h-96 w-96 rounded-full border-[38px] border-white/5 pointer-events-none" />
          <div className="absolute bottom-[-6rem] left-[42%] h-64 w-64 rounded-full border border-white/10 pointer-events-none" />
          
          <div className="relative mx-auto max-w-7xl">
            <div className="flex flex-wrap items-center gap-3 text-xs font-bold uppercase tracking-[.18em] text-secondary">
              <a href="/blog" className="hover:text-white transition-colors">Field Notes</a>
              <span>/</span>
              <span className="text-white/80">Knowledge Center</span>
            </div>
            
            <div className="mt-7 grid gap-10 lg:grid-cols-[1fr_330px] lg:items-end">
              <div>
                <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-secondary/30 bg-secondary/10 px-4 py-2 text-xs font-bold uppercase tracking-[.14em] text-secondary">
                  <Waves className="h-4 w-4" /> 
                  Local pool care, decoded
                </div>
                <h1 className="max-w-4xl font-display text-4xl font-extrabold leading-[1.07] md:text-5xl lg:text-6xl text-white">
                  Clear water is a system,<br className="hidden md:block"/> not a coincidence.
                </h1>
                <p className="mt-6 max-w-2xl text-lg md:text-xl leading-relaxed text-white/80">
                  Ten practical guides for the heat, hard water, wind, dust, and equipment realities of Riverside County. Know what to test, what to clean, and when a warning deserves a professional look.
                </p>
              </div>
              
              <div className="rounded-2xl border border-white/10 bg-white/5 p-6 backdrop-blur-sm">
                <div className="flex items-center gap-3">
                  <Clock3 className="h-6 w-6 text-secondary" />
                  <span className="text-sm font-bold text-white">10 topics · about 22 minutes</span>
                </div>
                <p className="mt-4 text-sm leading-relaxed text-white/70">
                  Chemistry, filtration, equipment care, algae, weather recovery, and restorative cleaning—written for homeowners in Murrieta, Temecula, and beyond.
                </p>
              </div>
            </div>
          </div>
        </section>

        {/* CONTENT GRID */}
        <div className="mx-auto max-w-7xl px-6 py-12 lg:py-16">
          <div className="grid gap-12 lg:grid-cols-[260px_1fr]">
            {/* Sidebar */}
            <aside className="hidden lg:block">
              <div className="sticky top-32">
                <p className="mb-5 text-xs font-bold uppercase tracking-[.18em] text-slate-400">In this guide</p>
                <nav className="space-y-1">
                  {topics.map((topic) => (
                    <a href={`#${topic.id}`} key={topic.id} className="flex gap-3 rounded-lg px-3 py-2.5 text-sm text-slate-600 font-medium transition-colors hover:bg-slate-100 hover:text-primary">
                      <span className="font-mono text-[10px] text-secondary font-bold mt-0.5">{topic.number}</span>
                      <span className="leading-snug">{topic.title}</span>
                    </a>
                  ))}
                </nav>
                <div className="mt-10 rounded-2xl bg-primary p-6 text-white shadow-xl shadow-primary/10">
                  <ShieldCheck className="mb-4 h-8 w-8 text-secondary" />
                  <p className="text-base font-bold leading-snug">Not sure what your water is telling you?</p>
                  <a href="/#contact" className="mt-5 inline-flex items-center gap-2 text-sm font-bold text-secondary hover:text-white transition-colors">
                    Book a water check <ArrowRight className="h-4 w-4" />
                  </a>
                </div>
              </div>
            </aside>

            {/* Articles */}
            <div>
              <div className="mb-8 flex flex-col gap-6 border-b border-border pb-8 sm:flex-row sm:items-end sm:justify-between">
                <div>
                  <p className="text-xs font-bold uppercase tracking-[.18em] text-secondary">The care library</p>
                  <h2 className="mt-3 font-display text-2xl font-extrabold md:text-3xl text-primary">Ten answers for the pool you have today.</h2>
                  <p className="mt-3 max-w-xl text-base text-slate-600">Open a topic for field-tested details and a Rivera Pool Care takeaway.</p>
                </div>
                <label className="relative block sm:w-72 shrink-0">
                  <Search className="absolute left-4 top-3.5 h-4 w-4 text-slate-400" />
                  <input type="search" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Search chemistry, algae..." className="w-full rounded-xl border border-border bg-white py-3 pl-11 pr-4 text-sm outline-none transition focus:border-secondary focus:ring-2 focus:ring-secondary/20 shadow-sm" />
                </label>
              </div>

              <div className="mb-8 flex gap-3 overflow-x-auto pb-2 lg:hidden scrollbar-hide">
                {topics.map((topic) => (
                  <a href={`#${topic.id}`} key={topic.id} className="shrink-0 rounded-full border border-border bg-white px-4 py-2 text-xs font-bold text-slate-600 hover:border-secondary hover:text-secondary transition-colors">
                    <span className="text-secondary mr-1">{topic.number}</span> {topic.kicker}
                  </a>
                ))}
              </div>

              <div className="space-y-6">
                {filtered.map((topic) => (
                  <article id={topic.id} key={topic.id} className="scroll-mt-32 overflow-hidden rounded-2xl border border-border bg-white shadow-sm transition-shadow hover:shadow-md">
                    <button onClick={() => setActive(active === topic.id ? null : topic.id)} className="flex w-full items-start gap-4 p-6 text-left md:p-8 focus:outline-none focus:bg-slate-50 transition-colors" aria-expanded={active === topic.id}>
                      <span className="font-mono text-sm font-bold text-secondary">{topic.number}</span>
                      <span className="flex-1">
                        <span className="block text-xs font-bold uppercase tracking-[.17em] text-slate-400">{topic.kicker}</span>
                        <span className="mt-2 block font-display text-xl font-bold leading-tight md:text-2xl text-primary">{topic.title}</span>
                        <span className="mt-4 block max-w-3xl text-base leading-relaxed text-slate-600">{topic.intro}</span>
                        <span className="mt-5 flex flex-wrap gap-2">
                          {topic.tags.map((tag) => (
                            <span key={tag} className="rounded-full bg-slate-100 border border-slate-200 px-3 py-1 text-[11px] font-bold text-slate-500 uppercase tracking-wider">#{tag}</span>
                          ))}
                        </span>
                      </span>
                      <ChevronDown className={`mt-1 h-5 w-5 shrink-0 text-slate-400 transition-transform duration-300 ${active === topic.id ? "rotate-180" : ""}`} />
                    </button>
                    {active === topic.id && (
                      <div className="border-t border-slate-100 bg-slate-50 px-6 pb-8 pt-7 md:px-[5.5rem] animate-in slide-in-from-top-4 duration-300">
                        <ul className="space-y-5">
                          {topic.facts.map((fact) => (
                            <li key={fact} className="flex gap-4 text-base leading-relaxed text-slate-700">
                              <Check className="mt-1 h-5 w-5 shrink-0 text-secondary" />
                              {fact}
                            </li>
                          ))}
                        </ul>
                        <div className="mt-8 flex gap-4 rounded-xl border-l-4 border-secondary bg-orange-50/50 p-5 text-base leading-relaxed text-slate-800 shadow-sm">
                          <CircleAlert className="mt-0.5 h-5 w-5 shrink-0 text-secondary" />
                          <span><strong className="font-bold text-primary">Rivera Pool Care takeaway:</strong> {topic.takeaway}</span>
                        </div>
                      </div>
                    )}
                  </article>
                ))}
              </div>
              
              {filtered.length === 0 && (
                <div className="rounded-2xl border-2 border-dashed border-border bg-slate-50 p-16 text-center">
                  <Filter className="mx-auto h-8 w-8 text-slate-400" />
                  <p className="mt-4 font-display text-lg font-bold text-primary">No matching topics found</p>
                  <p className="mt-2 text-slate-500 text-sm">Try adjusting your search terms.</p>
                  <Button onClick={() => setQuery("")} variant="outline" className="mt-6 font-bold">Clear search</Button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* CTA SECTION */}
        <section className="bg-secondary/10 px-6 py-16 lg:py-20 border-t border-border">
          <div className="mx-auto flex max-w-7xl flex-col items-start justify-between gap-8 md:flex-row md:items-center">
            <div>
              <p className="text-xs font-bold uppercase tracking-[.18em] text-secondary">Good maintenance catches patterns</p>
              <h2 className="mt-3 font-display text-3xl font-extrabold text-primary">Bring the warning sign to the site visit.</h2>
              <p className="mt-4 max-w-2xl text-lg text-slate-700">Rivera Pool Care can test the water, inspect the equipment, and explain whether you need routine care, a restoration, or a larger repair.</p>
            </div>
            <Button asChild className="h-14 shrink-0 px-8 bg-secondary hover:bg-secondary/90 text-white rounded-xl font-bold shadow-xl shadow-secondary/20 transition-all hover:-translate-y-0.5">
              <a href="/#contact">Request a water assessment <ArrowRight className="ml-2 h-5 w-5" /></a>
            </Button>
          </div>
        </section>
      </main>

      {/* FOOTER */}
      <footer className="bg-primary pt-16 pb-8 border-t border-white/10">
        <div className="container mx-auto px-6 max-w-7xl">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12 mb-12">
            <div>
              <div className="flex items-center gap-2 mb-6">
                <div className="bg-white/10 p-2 rounded-xl text-secondary">
                  <Droplets className="w-5 h-5" />
                </div>
                <span className="font-display font-bold text-xl text-white tracking-tight">
                  RIVERA <span className="font-medium text-sm opacity-80">POOL CARE</span>
                </span>
              </div>
              <p className="text-white/60 text-sm leading-relaxed max-w-xs">
                Dependable, family-owned pool cleaning and equipment repair services for Riverside County.
              </p>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6 tracking-wide">Service Area</h4>
              <ul className="space-y-3 text-white/60 text-sm">
                <li><a href="/blog" className="text-secondary font-bold hover:text-white transition-colors">Knowledge Center &amp; Blog</a></li>
                <li><a href="/murrieta" className="hover:text-white transition-colors">Pool service in Murrieta, CA</a></li>
                <li><a href="/temecula" className="hover:text-white transition-colors">Pool service in Temecula, CA</a></li>
                <li><a href="/lake-elsinore" className="hover:text-white transition-colors">Pool service in Lake Elsinore, CA</a></li>
                <li><a href="/winchester" className="hover:text-white transition-colors">Pool service in Winchester, CA</a></li>
                <li><a href="/canyon-lake" className="hover:text-white transition-colors">Pool service in Canyon Lake, CA</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="text-white font-bold mb-6 tracking-wide">Contact Us</h4>
              <ul className="space-y-4 text-white/60 text-sm">
                <li className="flex items-center gap-3">
                  <Phone className="w-4 h-4 text-secondary" />
                  <a href="tel:+19513839753" className="hover:text-white transition-colors">(951) 383-9753</a>
                </li>
                <li className="flex items-center gap-3">
                  <Mail className="w-4 h-4 text-secondary" />
                  <a href="mailto:claudio@prospoolcare.com" className="hover:text-white transition-colors">claudio@prospoolcare.com</a>
                </li>
                <li className="flex items-center gap-3 mt-4">
                  <div className="px-3 py-1 bg-white/10 rounded-md text-xs font-bold text-white tracking-wider">HABLAMOS ESPAÑOL</div>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="pt-8 border-t border-white/10 text-center text-white/40 text-xs flex flex-col md:flex-row justify-between items-center gap-4">
            <p>&copy; {new Date().getFullYear()} Rivera Pool Care. All rights reserved.</p>
            <p>Weekly service and dependable repairs for Southwest Riverside County.</p>
          </div>
        </div>
      </footer>
      <ChatWidget />
    </div>
  );
}