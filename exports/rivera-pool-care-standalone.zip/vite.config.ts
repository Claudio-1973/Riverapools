import path from 'path';
import react from '@vitejs/plugin-react';
import tailwindcss from '@tailwindcss/vite';
import { defineConfig } from 'vite';
import { mkdir, readFile, writeFile } from 'node:fs/promises';

import runtimeErrorOverlay from '@replit/vite-plugin-runtime-error-modal';

const rawPort = process.env.PORT ?? '3000';

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

const basePath = process.env.BASE_PATH ?? '/';

const localPages = [
  {
    slug: 'murrieta',
    city: 'Murrieta',
    title: 'Pool Cleaning & Repair in Murrieta, CA | Rivera Pool Care',
    description: 'Reliable pool cleaning, chemical balancing, filter care, and equipment repair in Murrieta, CA. Call Rivera Pool Care for a free estimate.',
  },
  {
    slug: 'temecula',
    city: 'Temecula',
    title: 'Pool Cleaning & Repair in Temecula, CA | Rivera Pool Care',
    description: 'Weekly pool cleaning, water balancing, filter service, and pool equipment repair in Temecula, CA. Request a free estimate from our local team.',
  },
  {
    slug: 'lake-elsinore',
    city: 'Lake Elsinore',
    title: 'Pool Cleaning in Lake Elsinore, CA | Rivera Pool Care',
    description: 'Dependable pool cleaning, green-pool recovery, filter care, and equipment repair in Lake Elsinore, CA. Call today for a free service estimate.',
  },
  {
    slug: 'winchester',
    city: 'Winchester',
    title: 'Pool Cleaning & Repair in Winchester, CA | Rivera Pool Care',
    description: 'Professional weekly pool cleaning, chemical balancing, filter service, and equipment repair for Winchester, CA homes. Get a free estimate today.',
  },
  {
    slug: 'canyon-lake',
    city: 'Canyon Lake',
    title: 'Pool Cleaning & Repair in Canyon Lake, CA | Rivera Pool Care',
    description: 'Local pool cleaning, chemical balancing, filter maintenance, and equipment repair in Canyon Lake, CA. Call Rivera Pool Care for a free estimate.',
  },
];

function localSeoPages() {
  return {
    name: 'local-seo-pages',
    apply: 'build' as const,
    async closeBundle() {
      const outputDirectory = path.resolve(import.meta.dirname, 'dist/public');
      const shell = await readFile(path.join(outputDirectory, 'index.html'), 'utf8');

      const blogRouteDirectory = path.join(outputDirectory, 'blog');
      await mkdir(blogRouteDirectory, { recursive: true });
      const blogHtml = shell
        .replace(/<title>.*?<\/title>/, `<title>Pool Cleaning &amp; Maintenance Knowledge Center | Rivera Pool Care</title>`)
        .replace(/<meta name="description" content=".*?" \/>/, `<meta name="description" content="Ten practical pool cleaning and maintenance guides for Riverside County homeowners, covering chemistry, filtration, equipment, algae, weather, and restorative cleaning." />`)
        .replace(/<link rel="canonical" href=".*?" \/>/, `<link rel="canonical" href="https://prospoolcare.com/blog" />`)
        .replace(/<meta property="og:title" content=".*?" \/>/, `<meta property="og:title" content="Pool Cleaning &amp; Maintenance Knowledge Center | Rivera Pool Care" />`)
        .replace(/<meta property="og:description" content=".*?" \/>/, `<meta property="og:description" content="Ten practical pool cleaning and maintenance guides for Riverside County homeowners." />`)
        .replace(/<meta property="og:url" content=".*?" \/>/, `<meta property="og:url" content="https://prospoolcare.com/blog" />`)
        .replace(/<meta name="twitter:title" content=".*?" \/>/, `<meta name="twitter:title" content="Pool Cleaning &amp; Maintenance Knowledge Center | Rivera Pool Care" />`)
        .replace(/<meta name="twitter:description" content=".*?" \/>/, `<meta name="twitter:description" content="Ten practical pool cleaning and maintenance guides for Riverside County homeowners." />`)
        .replace('<div id="root"></div>', `<div id="root"><main data-static-seo-fallback><h1>Pool Cleaning &amp; Maintenance Knowledge Center</h1><p>Ten practical guides for the heat, hard water, wind, dust, and equipment realities of Riverside County.</p></main></div>`);
      await writeFile(path.join(blogRouteDirectory, 'index.html'), blogHtml);

      for (const page of localPages) {
        const url = `https://prospoolcare.com/${page.slug}`;
        const cityLinks = localPages
          .map(({ slug, city }) => `<a href="/${slug}">Pool service in ${city}, CA</a>`)
          .join('');
        const staticPage = [
          '<main data-static-seo-fallback>',
          `<h1>Pool Cleaning &amp; Equipment Repair in ${page.city}, CA</h1>`,
          `<nav aria-label="Pool service areas">${cityLinks}</nav>`,
          '</main>',
        ].join('');
        const html = shell
          .replace(/<title>.*?<\/title>/, `<title>${page.title}</title>`)
          .replace(/<meta name="description" content=".*?" \/>/, `<meta name="description" content="${page.description}" />`)
          .replace(/<link rel="canonical" href=".*?" \/>/, `<link rel="canonical" href="${url}" />`)
          .replace(/<meta property="og:title" content=".*?" \/>/, `<meta property="og:title" content="${page.title}" />`)
          .replace(/<meta property="og:description" content=".*?" \/>/, `<meta property="og:description" content="${page.description}" />`)
          .replace(/<meta property="og:url" content=".*?" \/>/, `<meta property="og:url" content="${url}" />`)
          .replace(/<meta name="twitter:title" content=".*?" \/>/, `<meta name="twitter:title" content="${page.title}" />`)
          .replace(/<meta name="twitter:description" content=".*?" \/>/, `<meta name="twitter:description" content="${page.description}" />`)
          .replace('<div id="root"></div>', `<div id="root">${staticPage}</div>`);
        const routeDirectory = path.join(outputDirectory, page.slug);
        await mkdir(routeDirectory, { recursive: true });
        await writeFile(path.join(routeDirectory, 'index.html'), html);
      }
    },
  };
}

export default defineConfig({
  base: basePath,
  plugins: [
    react(),
    tailwindcss(),
    localSeoPages(),
    runtimeErrorOverlay(),
    ...(process.env.NODE_ENV !== 'production' &&
    process.env.REPL_ID !== undefined
      ? [
          await import('@replit/vite-plugin-cartographer').then((m) =>
            m.cartographer({
              root: path.resolve(import.meta.dirname, '..'),
            }),
          ),
          await import('@replit/vite-plugin-dev-banner').then((m) =>
            m.devBanner(),
          ),
        ]
      : []),
  ],
  resolve: {
    alias: {
      '@': path.resolve(import.meta.dirname, 'src'),
    },
    dedupe: ['react', 'react-dom'],
  },
  root: path.resolve(import.meta.dirname),
  build: {
    outDir: path.resolve(import.meta.dirname, 'dist/public'),
    emptyOutDir: true,
  },
  server: {
    port,
    strictPort: true,
    host: '0.0.0.0',
    allowedHosts: true,
    fs: {
      strict: true,
    },
  },
  preview: {
    port,
    host: '0.0.0.0',
    allowedHosts: true,
  },
});
