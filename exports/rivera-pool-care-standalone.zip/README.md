# Rivera Pool Care — prospoolcare.com

Standalone React/Vite project for Rivera Pool Care, including the searchable pool-care knowledge center at /blog.

## Start locally

1. Run `pnpm install`.
2. Add Replit Secrets: `VITE_WEB3FORMS_ACCESS_KEY` and `GEMINI_API_KEY`.
3. Run `pnpm dev`.

The app defaults to port 3000 and base path `/`.

## Production

Reconnect the existing Vercel project `rivera-pool-care` instead of creating another production project. Add both secrets to Vercel Production before deploying.

This export intentionally excludes secret values, local environment files, Vercel linkage metadata, build output, and dependencies.
